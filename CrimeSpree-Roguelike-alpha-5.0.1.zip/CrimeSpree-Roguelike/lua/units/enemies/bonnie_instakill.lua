-- Bonnie's Lucky Chip - Instant Kill Mechanic
-- Chance to instantly kill an enemy on hit

if not RequiredScript then
	return
end

-- ==========================================
-- SOUND LOADING (XAudio, same pattern as Plush Shark)
-- ==========================================
-- Loads all chip_proc_N.ogg variants and picks one at random per proc
_G.CSR_BonnieChipSoundBuffers = _G.CSR_BonnieChipSoundBuffers or {}

local function CSR_log(msg)
	if _G.CSR_Settings and _G.CSR_Settings.values and _G.CSR_Settings.values.debug_mode then
		log("[CSR][BonnieChip] " .. tostring(msg))
	end
end

if #_G.CSR_BonnieChipSoundBuffers == 0 then
	-- ModPath at hook time may point to a different mod — use hardcoded path
	local MOD_PATH = "mods/CrimeSpree-Roguelike/"
	local VARIANT_COUNT = 17

	DelayedCalls:Add("CSR_LoadBonnieChipSound", 1.0, function()
		if not (_G.blt and _G.blt.xaudio) then
			CSR_log("XAudio not available")
			return
		end

		blt.xaudio.setup()

		local base_path = Application:base_path()
		if base_path and base_path:sub(-1) ~= "/" and base_path:sub(-1) ~= "\\" then
			base_path = base_path .. "/"
		end

		for i = 1, VARIANT_COUNT do
			local relative_path = MOD_PATH .. "assets/sounds/chip/chip_proc_" .. i .. ".ogg"
			local absolute_path = base_path .. relative_path

			local fh = io.open(absolute_path, "rb")
			local found_absolute = fh ~= nil
			if fh then
				fh:close()
			else
				fh = io.open(relative_path, "rb")
				if fh then
					fh:close()
				end
			end

			if fh then
				local path_to_load = found_absolute and absolute_path or relative_path
				local ok, buf = pcall(function()
					return XAudio.Buffer:new(path_to_load)
				end)
				if ok and buf then
					table.insert(_G.CSR_BonnieChipSoundBuffers, buf)
				else
					CSR_log("Buffer FAILED for " .. tostring(path_to_load) .. ": " .. tostring(buf))
				end
			else
				CSR_log("File NOT FOUND: " .. tostring(absolute_path))
			end
		end

		CSR_log("Loaded " .. #_G.CSR_BonnieChipSoundBuffers .. " chip proc sounds")
	end)
end

-- ==========================================
-- INSTAKILL MECHANIC
-- ==========================================

-- Instakill chance and cooldown from centralized constants
local C = _G.CSR_ItemConstants or {}
local INSTAKILL_CHANCE = (C.bonnie_chip_chance or 0.05) * 100 -- convert fraction to percent
local INSTAKILL_COOLDOWN = C.bonnie_chip_cooldown or 1.5
local last_instakill_time = 0

-- Count Bonnie's Lucky Chip stacks
local function count_bonnie_chips()
	return CSR_CountStacks("player_bonnie_chip_")
end

-- Clean up stale UnitSource from previous heist so stop()/close() on a dead unit
-- doesn't produce an audio glitch at the start of heist 2+.
Hooks:PostHook(PlayerDamage, "init", "CSR_BonnieChip_CleanupSound", function(self)
	if _G._csr_chip_sound_source then
		pcall(function()
			if not _G._csr_chip_sound_source:is_closed() then
				_G._csr_chip_sound_source:stop()
				_G._csr_chip_sound_source:close()
			end
		end)
		_G._csr_chip_sound_source = nil
	end
end)

-- Hook on enemy damage
Hooks:PostHook(CopDamage, "damage_bullet", "CSR_BonnieChipInstakill", function(self, attack_data)
	if not managers.crime_spree or not managers.crime_spree:is_active() then
		return
	end
	-- Guard: damage must come from a player
	if not attack_data or not attack_data.attacker_unit or not attack_data.attacker_unit:base() then
		return
	end

	-- Guard: attacker must be the local player
	if not attack_data.attacker_unit:base().is_local_player then
		return
	end

	-- Guard: player must have Bonnie's Lucky Chip
	local chip_count = count_bonnie_chips()
	if chip_count == 0 then
		return
	end

	-- Guard: enemy must still be alive
	if not self._unit or not alive(self._unit) or self._dead then
		return
	end

	-- Guard: don't instakill converted cops (jokers / minions)
	if self._converted then
		return
	end

	-- Check cooldown (protection against minigun/shotgun spam)
	local current_time = TimerManager:game():time()
	local time_since_last = current_time - last_instakill_time
	if time_since_last < INSTAKILL_COOLDOWN then
		-- Cooldown active, skip the roll
		return
	end

	-- Start cooldown on EVERY attempt, not just procs — prevents minigun spam
	last_instakill_time = current_time

	-- VHUDPlus: show cooldown timer (fires on every attempt)
	if CSR_VHUDPlusEvent then
		CSR_VHUDPlusEvent("timed_buff", "activate", "csr_bonnie_chip_cd", {
			t = current_time,
			duration = INSTAKILL_COOLDOWN,
		})
	end
	if CSR_WFHudEvent then
		CSR_WFHudEvent("activate", "bonnie_chip_cd", { duration = INSTAKILL_COOLDOWN })
	end
	if CSR_PocoHudEvent then
		CSR_PocoHudEvent("activate", "bonnie_chip_cd", { duration = INSTAKILL_COOLDOWN })
	end

	-- Roll instakill chance (per stack)
	-- Formula: 1 - (1 - chance)^stacks (independent rolls)
	local total_chance = 1 - math.pow(1 - INSTAKILL_CHANCE / 100, chip_count)
	local roll = math.random()

	if roll <= total_chance then
		if self._unit and alive(self._unit) and not self._dead then
			-- Kill the enemy directly via die() to avoid recursive damage_bullet re-entry
			-- Re-entering damage_bullet from a PostHook causes C-level access violations
			-- that pcall cannot catch
			local kill_data
			pcall(function()
				kill_data = clone(attack_data)
			end)
			if not kill_data then
				kill_data = { attacker_unit = attack_data.attacker_unit, weapon_unit = attack_data.weapon_unit }
			end
			kill_data.damage = self._health
			kill_data.result = { type = "death", variant = attack_data.variant or "bullet" }
			pcall(function()
				self:die(kill_data)
			end)
			-- die() alone doesn't notify damage listeners or AI manager.
			-- Without _on_damage_received, the brain never enters dead state
			-- and the enemy becomes an invincible zombie (can still shoot).
			-- Separate pcall so a crash in _on_damage_received can't block die().
			if self._dead then
				pcall(function()
					self:_on_damage_received(kill_data)
				end)

				-- Play activation sound ONLY on confirmed kill.
				-- Attached to the player unit (stable) instead of the dying enemy.
				local buffers = _G.CSR_BonnieChipSoundBuffers
				if buffers and #buffers > 0 then
					local player_unit = attack_data.attacker_unit
					local chosen_buffer = buffers[math.random(#buffers)]
					pcall(function()
						if _G._csr_chip_sound_source then
							pcall(function()
								if not _G._csr_chip_sound_source:is_closed() then
									_G._csr_chip_sound_source:stop()
									_G._csr_chip_sound_source:close()
								end
							end)
							_G._csr_chip_sound_source = nil
						end
						_G._csr_chip_sound_source = XAudio.UnitSource:new(player_unit, chosen_buffer)
						local sv = _G.CSR_Settings and _G.CSR_Settings.values
						local vol = (sv and sv.bonnie_chip_sound_volume ~= nil) and sv.bonnie_chip_sound_volume or 0.5
						_G._csr_chip_sound_source:set_volume(vol)
						_G._csr_chip_sound_source:play()
					end)
				end
			end
		end
	end
end)
