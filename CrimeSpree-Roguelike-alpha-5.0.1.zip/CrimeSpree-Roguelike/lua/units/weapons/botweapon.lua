-- Crime Spree Roguelike - Bot weapon damage passive progression
-- Marks bot weapons at setup, then multiplies dmg_mul on fire.
-- Bots get +1% damage per CS level.

if not RequiredScript then
	return
end

local C = _G.CSR_ItemConstants or {}
local BOT_DMG_PER_LEVEL = C.bot_damage_per_level or 0.01 -- +1% per CS level

-- Mark weapons belonging to AI teammates at setup time.
-- Vanilla check pattern: compare user_unit against local player unit.
-- NewRaycastWeaponBase weapons are only used by players and AI teammates,
-- so any non-player owner is a bot.
Hooks:PostHook(NewRaycastWeaponBase, "setup", "CSR_BotWeaponMark", function(self)
	local owner = self._setup and self._setup.user_unit
	if not alive(owner) then
		return
	end
	local player_unit = managers.player and managers.player:player_unit()
	if owner ~= player_unit then
		self._csr_is_bot_weapon = true
	end
end)

-- Function override required: PreHook cannot modify parameters,
-- PostHook cannot modify parameters either.
-- dmg_mul must be scaled before NewRaycastWeaponBase.fire runs.
local _original_fire = NewRaycastWeaponBase.fire
_G.CSR_SafeOverride(
	NewRaycastWeaponBase,
	"fire",
	"Bot Damage",
	_original_fire,
	function(self, from_pos, direction, dmg_mul, ...)
		if self._csr_is_bot_weapon and managers.crime_spree and managers.crime_spree:is_active() then
			local spree_level = (_G.CSR_MP and CSR_MP.is_client and CSR_MP.is_client() and _G.CSR_MP_HostRank)
				or managers.crime_spree:spree_level()
				or 0
			if spree_level > 0 then
				dmg_mul = (dmg_mul or 1) * (1 + BOT_DMG_PER_LEVEL * spree_level)
			end
		end
		return _original_fire(self, from_pos, direction, dmg_mul, ...)
	end
)
