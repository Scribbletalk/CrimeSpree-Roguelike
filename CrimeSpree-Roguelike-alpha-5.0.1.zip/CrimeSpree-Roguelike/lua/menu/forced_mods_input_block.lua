-- Crime Spree Roguelike - Block input behind forced mods popup
-- When the popup is open, prevent all clicks from reaching menu components
-- and route mouse events to the popup itself

if not RequiredScript then
	return
end

local function _popup_active()
	local inst = _G.CSR_ForcedModsNotificationInstance
	return inst and alive(inst._panel)
end

-- Block mouse_pressed on all menu components while popup is open
local _original_mouse_pressed = MenuComponentManager.mouse_pressed

function MenuComponentManager:mouse_pressed(o, button, x, y)
	if _popup_active() then
		local inst = _G.CSR_ForcedModsNotificationInstance
		inst:mouse_pressed(button, x, y)
		return true
	end
	return _original_mouse_pressed(self, o, button, x, y)
end

-- Block mouse_clicked (tab switches use this, not mouse_released)
local _original_mouse_clicked = MenuComponentManager.mouse_clicked

function MenuComponentManager:mouse_clicked(o, button, x, y)
	if _popup_active() then
		return true
	end
	if _original_mouse_clicked then
		return _original_mouse_clicked(self, o, button, x, y)
	end
end

-- Block mouse_moved and route to popup for hover/cursor handling
local _original_mouse_moved = MenuComponentManager.mouse_moved

function MenuComponentManager:mouse_moved(o, x, y)
	local inst = _G.CSR_ForcedModsNotificationInstance
	if inst then
		if alive(inst._panel) then
			local used, cursor = inst:mouse_moved(x, y)
			if cursor then
				managers.mouse_pointer:set_pointer_image(cursor)
			end
			return used, cursor or "arrow"
		else
			_G.CSR_ForcedModsNotificationInstance = nil
		end
	end
	return _original_mouse_moved(self, o, x, y)
end
