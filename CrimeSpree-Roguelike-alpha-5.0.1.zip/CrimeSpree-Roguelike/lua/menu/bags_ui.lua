-- Crime Spree Roguelike - Cash Bonus UI
-- Display cash bonus (from secured bags) as additional earned crime spree levels

if not RequiredScript then
	return
end

-- Hook on level UI element creation - adds secured bags bonus display
Hooks:PostHook(CrimeSpreeResultTabItem, "_create_level", "CSR_ShowBagsBonus", function(self, total_w)
	-- Guard: only proceed if mission was successful
	if not self:success() then
		return
	end

	-- Get bonus bag count from CrimeSpreeManager
	local bonus_bags = 0
	if managers.crime_spree then
		if managers.crime_spree._csr_bonus_bags then
			bonus_bags = managers.crime_spree._csr_bonus_bags
		else
		end
	else
	end

	if bonus_bags <= 0 then
		return
	end

	-- Find the "gain" element (main text showing earned levels)
	local gain = self._level_panel:child("gain")
	if not gain then
		return
	end

	local gain_x = gain:center_x()

	-- Font settings (matching vanilla game style)
	local font = tweak_data.menu.pd2_small_font
	local font_size = tweak_data.menu.pd2_small_font_size
	local color = Color(1, 0.4, 0.8, 0.2) -- green

	-- Create "Cash Bonus" label (start with alpha=0 for vanilla animation)
	local bonus_label = self._level_panel:text({
		name = "csr_bags_label",
		blend_mode = "add",
		vertical = "center",
		alpha = 0,
		align = "center",
		layer = 10,
		text = managers.localization:to_upper_text("menu_csr_cash_bonus"),
		h = font_size,
		font_size = font_size,
		font = font,
		color = color,
	})

	self:make_fine_text(bonus_label)
	bonus_label:set_center_x(gain_x)
	bonus_label:set_top(gain:bottom() + 10)

	-- Create "+X levels" text
	local bonus_amount = self._level_panel:text({
		name = "csr_bags_amount",
		vertical = "center",
		blend_mode = "add",
		w = 200,
		align = "center",
		alpha = 0,
		layer = 10,
		text = "+" .. managers.localization:text("menu_cs_level", { level = bonus_bags }),
		h = font_size,
		font_size = font_size,
		font = font,
		color = color,
	})

	bonus_amount:set_center_x(gain_x)
	bonus_amount:set_top(bonus_label:bottom())

	-- Append to vanilla animation queue at the END
	-- Vanilla _update_gain_calculate handles fade_in/fade_out for all bonus entries.
	-- DO NOT add a DelayedCalls that calls panel:remove() here -- vanilla animation coroutines
	-- on these elements may still be running when the timer fires, causing a C++ access violation.
	if self._levels and self._levels.bonuses then
		table.insert(self._levels.bonuses, {
			bonus_label,
			bonus_amount,
			bonus_bags,
		})
	end
end)
