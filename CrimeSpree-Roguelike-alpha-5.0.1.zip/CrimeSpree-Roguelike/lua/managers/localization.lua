-- Crime Spree Roguelike Alpha 1 - Localization with colors

local function CSR_log(msg)
	if _G.CSR_Settings and _G.CSR_Settings.values and _G.CSR_Settings.values.debug_mode then
		log(msg)
	end
end

CSR_log("[CSR Alpha1 LOC] localization hook loading")

-- Rarity colors (hex)
local COLORS = {
	common = "ffffff", -- white
	uncommon = "00ff00", -- green
	rare = "0099ff", -- blue
	contraband = "ff6600", -- orange (trade-off items)
	legendary = "ffd700", -- gold
}

-- Item data (player buffs) - English
local ITEMS_EN = {
	["menu_cs_modifier_player_health"] = {
		name = "DOG TAGS",
		desc = "Increases your max health.",
		rarity = "common",
	},
	["menu_cs_modifier_player_damage"] = {
		name = "EVIDENCE ROUNDS",
		desc = "All your attacks deal more damage.",
		rarity = "uncommon",
	},
	["csr_dozer_guide_desc"] = {
		name = "DOZER GUIDE",
		desc = "Greatly increases your armor.\nBut slows you down and reduces dodge.",
		rarity = "contraband",
	},
	["csr_bonnie_chip_desc"] = {
		name = "BONNIE'S LUCKY CHIP",
		desc = "Each hit has a small chance to instantly kill the target.",
		rarity = "rare", -- Blue color (PAYDAY 2 blue)
	},
	["csr_glass_cannon_desc"] = {
		name = "GLASS PISTOL",
		desc = "Massively increases all damage.\nBut halves your maximum health and armor.",
		rarity = "contraband",
	},
	["csr_car_keys_desc"] = {
		name = "FALCOGINI KEYS",
		desc = "Gives you a chance to dodge incoming damage.",
		rarity = "uncommon",
	},
	["csr_plush_shark_desc"] = {
		name = "PLUSH SHARK",
		desc = "Saves you from a killing blow once per life,\nrestores full health and armor,\nthen grants brief invulnerability.",
		rarity = "rare",
	},
	["csr_wolfs_toolbox_desc"] = {
		name = "WOLF'S TOOLBOX",
		desc = "Killing enemies reduces the timer\non active drills and saws.",
		rarity = "uncommon",
	},
	["menu_cs_modifier_duct_tape"] = {
		name = "DUCT TAPE",
		desc = "Makes you faster at interacting with objects.",
		rarity = "common",
	},
	["csr_escape_plan_desc"] = {
		name = "ESCAPE PLAN",
		desc = "Increases your movement speed.",
		rarity = "common",
	},
	["csr_worn_bandaid_desc"] = {
		name = "WORN BAND-AID",
		desc = "Slowly regenerates a small amount of health over time.",
		rarity = "common",
	},
	["csr_piece_of_rebar_desc"] = {
		name = "PIECE OF REBAR",
		desc = "Your first hit on an enemy deals bonus damage.",
		rarity = "common",
	},
	["csr_jiro_last_wish_desc"] = {
		name = "JIRO'S LAST WISH",
		desc = "Sprint while charging a melee attack. Increases melee damage.",
		rarity = "rare",
	},
	["csr_dearest_possession_desc"] = {
		name = "DEAREST POSSESSION",
		desc = "Healing at full HP converts to temporary shields that quickly fade away.",
		rarity = "rare",
	},
	["csr_viklund_vinyl_desc"] = {
		name = "VIKLUND'S VINYL",
		desc = "...and his beats were electric.",
		rarity = "rare",
	},
	["csr_equalizer_desc"] = {
		name = "EQUALIZER",
		desc = "Greatly increases damage against special enemies.\nBut reduces it against regular ones.",
		rarity = "contraband",
	},
	["csr_crooked_badge_desc"] = {
		name = "CROOKED BADGE",
		desc = "Chance to restore a down after each assault.\nBut your bleedout timer is reduced.",
		rarity = "contraband",
	},
	["csr_dead_mans_trigger_desc"] = {
		name = "DEAD MAN'S TRIGGER",
		desc = "Going down triggers an explosion around you.\nBut allies also receive damage from it.",
		rarity = "contraband",
	},
	["csr_half_a_glass_desc"] = {
		name = "HALF-A-GLASS",
		desc = "Gage packages restore some ammo and raise your max ammo.",
		rarity = "common",
	},
	["csr_overkill_rush_desc"] = {
		name = "OVERKILL RUSH",
		desc = "Killing enemies temporarily increases fire rate and reload speed.",
		rarity = "uncommon",
	},
	["csr_pink_slip_desc"] = {
		name = "PINK SLIP",
		desc = "Killing an enemy restores health.",
		rarity = "uncommon",
	},
	["csr_the_edge_desc"] = {
		name = "THE EDGE",
		desc = "When critically low on health,\nrestores health and grants brief invulnerability.",
		rarity = "uncommon",
	},
	-- Dummy modifiers (should not appear in popup, but need localization just in case)
	["csr_base_modifier"] = {
		name = "",
		desc = "",
		rarity = "common",
	},
	["csr_dummy_5"] = { name = "", desc = "", rarity = "common" },
	["csr_dummy_10"] = { name = "", desc = "", rarity = "common" },
	["csr_dummy_15"] = { name = "", desc = "", rarity = "common" },
	["csr_dummy_30"] = { name = "", desc = "", rarity = "common" },
	["csr_dummy_35"] = { name = "", desc = "", rarity = "common" },
	["csr_dummy_45"] = { name = "", desc = "", rarity = "common" },
	["csr_dummy_55"] = { name = "", desc = "", rarity = "common" },
	["csr_dummy_65"] = { name = "", desc = "", rarity = "common" },
	["csr_dummy_70"] = { name = "", desc = "", rarity = "common" },
	["csr_dummy_85"] = { name = "", desc = "", rarity = "common" },
	["csr_dummy_90"] = { name = "", desc = "", rarity = "common" },
	["csr_dummy_95"] = { name = "", desc = "", rarity = "common" },
	-- Enemy HP/DMG (virtual modifier for UI)
	["csr_enemy_hp_damage_total"] = {
		name = "ENEMY HEALTH & DAMAGE",
		desc = "Increases with Crime Spree level",
		rarity = "forced",
	},
	-- Unlock modifiers
	["csr_enable_bulldozers_desc"] = {
		name = "YOU'RE UP AGAINST THE WALL AND I AM THE FUCKING WALL!",
		desc = "Bulldozers can now spawn on missions",
		rarity = "unlock",
	},
	["csr_enable_medics_desc"] = {
		name = "Don't worry, I'm here! And I brought drugs!",
		desc = "Medics can now spawn on missions",
		rarity = "unlock",
	},
	["csr_enable_tasers_desc"] = {
		name = "I'm the fucking SPARK MAN!",
		desc = "Tasers can now spawn on missions",
		rarity = "unlock",
	},
	["csr_enable_cloakers_desc"] = {
		name = "You call this resisting arrest? We call this a difficulty tweak!",
		desc = "Cloakers can now spawn on missions",
		rarity = "unlock",
	},
}

-- Overridden vanilla modifiers - English
local VANILLA_OVERRIDES_EN = {
	-- Loud modifiers
	["menu_cs_modifier_cloaker_tear_gas"] = "Stinkbug\nKilled Cloakers leave behind a toxic cloud that drains 5% of your max health every second.",
	["menu_cs_modifier_taser_overcharge"] = "Rapid Shock\nThe tasing knockout effect of the Taser now knocks a player out 50% faster",
	["menu_cs_modifier_dozer_rage"] = "No Faceplate, No Mercy\nWhen a Bulldozer's faceplate is destroyed, the Bulldozer enters a berserker rage, receiving a 100% increase to their base damage output",
	["menu_cs_modifier_more_dozers"] = "Heavy Reinforcement\nTwo additional Bulldozers are allowed into the level",
	["menu_cs_modifier_more_medics"] = "Field Hospital\nTwo additional Medics are allowed into the level",
	["menu_cs_modifier_heal_speed"] = "Autodidact\nMedic heal cooldown is 20% faster",
	["menu_cs_modifier_assault_extender"] = "Extended Assault\nPolice assaults will have a 40% longer duration. This gets reduced by 5% for every hostage and converted cop, up to a maximum of 4",
	-- Stealth modifiers - Less Pagers (4 tiers)
	["menu_cs_modifier_less_pagers_1"] = "Keen Dispatch\n1 less pager can be answered per heist",
	["menu_cs_modifier_less_pagers_2"] = "Keen Dispatch\n2 less pagers can be answered per heist",
	["menu_cs_modifier_less_pagers_3"] = "Keen Dispatch\n3 less pagers can be answered per heist",
	["menu_cs_modifier_less_pagers_4"] = "Keen Dispatch\n4 less pagers can be answered per heist",
	-- Stealth modifiers - Civilian Alarm (3 tiers)
	["menu_cs_modifier_civilian_alarm_1"] = "Witness Protection\nThe alarm will be sounded if more than 10 civilians are killed",
	["menu_cs_modifier_civilian_alarm_2"] = "Witness Protection\nThe alarm will be sounded if more than 7 civilians are killed",
	["menu_cs_modifier_civilian_alarm_3"] = "Witness Protection\nThe alarm will be sounded if more than 4 civilians are killed",
	-- Stealth modifiers - Less Concealment (same description, stacks)
	["menu_cs_modifier_less_concealment"] = "Stand Out\nDetection risk is increased by 3 (Stealth Only)",
	-- Add missing loud modifiers
	["menu_cs_modifier_no_hurt_anims"] = "Pain Tolerance\nEnemies have an 80% chance to resist stagger",
	["menu_cs_modifier_no_hurt"] = "Pain Tolerance\nEnemies have an 80% chance to resist stagger",
	["menu_cs_modifier_heavies"] = "Heavy Response\nAll FBI SWATs will be replaced with Heavy SWATs",
	["menu_cs_modifier_skulldozers"] = "Skulldozers\nSkulldozers can now appear alongside regular Bulldozers",
	["menu_cs_modifier_dozer_minigun"] = "Minigun Dozers\nWhenever a Bulldozer spawns, there is a chance that it will be a slow-moving minigun-wielding Bulldozer",
	["menu_cs_modifier_dozer_medic"] = "Medic Bulldozers\nWhenever a Bulldozer spawns, there is a chance that it will be a Medic Bulldozer",
	["menu_cs_modifier_shield_reflect"] = "Reflective Shields\nShields will reflect projectiles",
	["menu_cs_modifier_cloaker_smoke"] = "Smoke Bomb\nCloakers will drop a smokebomb when they kick a player",
	["menu_cs_modifier_heavy_sniper"] = "ZEAL Heavy SWAT Marksman\nFor every Heavy SWAT that spawns, there is a chance that it will be replaced by a ZEAL Heavy SWAT Marksman",
	["menu_cs_modifier_medic_adrenaline"] = "Combat Stimulant\nWhenever a Medic revives another cop, the revived cop gets a 100% increase to their base damage output",
	["menu_cs_modifier_shield_phalanx"] = "Phalanx Formation\nAll Shield units in the game are replaced by Captain Winters' Shield units",
	["menu_cs_modifier_medic_deathwish"] = "Final Dose\nWhenever a Medic is killed, all cops within the Medic's healing range are instantly healed",
	["menu_cs_modifier_explosion_immunity"] = "Blast Plating\nBulldozers take 50% reduced explosive damage",
	["menu_cs_modifier_cloaker_arrest"] = "\"You call this 'resisting' arrest?\"\nCloakers executing a successful charge now cuffs the player instead of downing them",
	["menu_cs_modifier_medic_rage"] = "Overdose\nFor every cop that dies within a Medic's healing range, that Medic sees his base damage output increased by 20%. This effect stacks indefinitely",
	["menu_cs_modifier_civilian_guilt"] = "Guilty Conscience\nEach civilian killed permanently reduces your max health by 5% for this mission, up to 30% total.",
	["menu_cs_modifier_shocking_surprise"] = "Shocking Surprise\nTasers release an electric burst on death, slowing nearby players and preventing sprint for 3 seconds",
	-- Enable modifiers (unlock enemy spawns on low difficulties)
	["menu_cs_modifier_enable_bulldozers"] = "YOU'RE UP AGAINST THE WALL AND I AM THE FUCKING WALL!\nBulldozers can now spawn on this difficulty",
	["menu_cs_modifier_enable_medics"] = "Don't worry, I'm here! And I brought drugs!\nMedics can now spawn on this difficulty",
	["menu_cs_modifier_enable_tasers"] = "I'm the fucking SPARK MAN!\nTasers can now spawn on this difficulty",
	["menu_cs_modifier_enable_cloakers"] = "You call this resisting arrest? We call this a difficulty tweak!\nCloakers can now spawn on this difficulty",
	-- Multiplayer
	["csr_mp_synced"] = "Synced with host",
	["csr_mp_host_picked"] = "Host picked",
	["csr_mp_lobby_blocked"] = "This lobby doesn't have CrimeSpree Roguelike",
	["csr_mp_auto_created"] = "You had no Crime Spree active. One was created for you at %s difficulty so you can earn rewards!",
}

Hooks:Add("LocalizationManagerPostInit", "CSR_Alpha1_Localization", function(loc)
	local ITEMS = ITEMS_EN
	local VANILLA_OVERRIDES = VANILLA_OVERRIDES_EN

	-- Build localization strings
	local strings = {}

	-- Player buffs (base keys)
	for key, item in pairs(ITEMS) do
		strings[key] = item.name .. "\n" .. item.desc
	end

	-- Dynamic localization for all item copies (up to 200 copies)
	-- Vanilla looks up localization by pattern: menu_cs_modifier_<modifier_id>
	-- Our IDs: player_health_boost_1, player_health_boost_2, ... player_health_boost_200
	-- Need to generate keys: menu_cs_modifier_player_health_boost_1, menu_cs_modifier_player_health_boost_2, etc.
	-- Item types generated from centralized registry
	local item_types = {}
	for _, item in ipairs(_G.CSR_ITEM_REGISTRY or {}) do
		table.insert(item_types, { prefix = item.id_prefix, base_key = item.loc_key })
	end

	for _, item_type in ipairs(item_types) do
		local base_item = ITEMS[item_type.base_key]
		if base_item then
			local text = base_item.name .. "\n" .. base_item.desc
			-- Generate keys for 200 copies
			for i = 1, 200 do
				local mod_id = item_type.prefix .. i
				local loc_key = "menu_cs_modifier_" .. mod_id
				strings[loc_key] = text
			end
			CSR_log("[CSR LOC] Generated 200 localization keys for: " .. item_type.prefix)
		end
	end

	-- Vanilla modifiers with fixed text
	for key, text in pairs(VANILLA_OVERRIDES) do
		strings[key] = text
	end

	-- Generate full-ID keys for forced modifiers so the vanilla Modifiers tab can find them.
	-- Vanilla UI looks up "menu_cs_modifier_" .. mod.id directly (e.g. "menu_cs_modifier_csr_civilian_guilt_20").
	-- We map each full ID to its base text using the same stripping logic as forced_mods_notification.
	local forced_mods = tweak_data.crime_spree
			and tweak_data.crime_spree.repeating_modifiers
			and tweak_data.crime_spree.repeating_modifiers.forced
		or {}
	for _, mod in ipairs(forced_mods) do
		if mod.id then
			local clean_id = mod.id:gsub("^csr_", "")
			local is_stealth_tiered = clean_id:find("^less_pagers_") or clean_id:find("^civilian_alarm_")
			local base_id = clean_id
			if not is_stealth_tiered then
				base_id = clean_id:gsub("_(%d+)$", "")
			end
			local base_text = strings["menu_cs_modifier_" .. base_id]
			if base_text then
				strings["menu_cs_modifier_" .. mod.id] = base_text
			end
		end
	end

	-- Items tab label
	strings["menu_csr_items"] = "ITEMS"
	strings["menu_csr_items_placeholder"] = "Collected items will show up here."

	-- Gage's Services tab (hosts Shop + Printer sub-tabs)
	strings["menu_csr_gage_services"] = "GAGE'S SERVICES"

	-- Printer tab labels
	strings["menu_csr_printer"] = "PRINTER"
	strings["menu_csr_printer_new"] = "PRINTER " .. utf8.char(0xE012)
	strings["csr_printer_empty"] = "No printer available.\nComplete a mission for a chance to find one."
	strings["csr_waiting_for_selections"] = "Waiting for players to select items... (%ds)"

	-- Printer interaction prompt (native PD2 Hold-to-Use).
	-- $BTN_INTERACT is a vanilla macro populated by BaseInteractionExt:_add_string_macros;
	-- it renders as the player's currently-bound interact key glyph (e.g. "[F]").
	-- The HUD uppercases the whole prompt, so the final on-screen text reads
	-- "HOLD [F] TO USE PRINTER".
	strings["csr_interact_copier"] = "Hold $BTN_INTERACT to use printer"
	strings["csr_interact_copier_action"] = "USING PRINTER"
	strings["csr_copier_no_item"] = "No matching-tier item to exchange"

	-- Printer penalty threshold messages (shown as red chat, local player only)
	-- Each key corresponds to a cumulative usage % threshold in the printer mechanic.
	strings["csr_printer_msg_1"] = "Something feels off..."
	strings["csr_printer_msg_15"] = "You feel weaker."
	strings["csr_printer_msg_35"] = "Pain comes easier now."
	strings["csr_printer_msg_50"] = "Your wounds run deeper."
	strings["csr_printer_msg_70"] = "You bleed too easily."
	strings["csr_printer_msg_85"] = "The cost catches up."
	strings["csr_printer_msg_100"] = "You are not gonna stop, aren't you?"

	-- Stats tab label
	strings["menu_csr_stats"] = "STATS"

	-- Override "Select Modifiers" with "Select Item/Items"
	strings["menu_cs_select_modifier"] = "SELECT ITEM"
	strings["menu_cs_select_modifiers"] = "SELECT ITEMS"
	strings["csr_auto_fill_items"] = "AUTO-FILL"
	strings["csr_auto_fill_confirm_title"] = "Auto-Fill Items"
	strings["csr_auto_fill_confirm_text"] =
		"Are you sure you want to auto-fill all remaining item slots with random items? This cannot be undone."
	strings["csr_items_ready"] = "READY"
	strings["csr_waiting_for_others"] = "Waiting for others to select items"
	strings["csr_all_players_ready"] = "All players ready"

	-- Lobby player status (shown below nickname during item selection)
	strings["menu_lobby_menu_state_selecting_item"] = "SELECTING ITEM"

	-- Ready system (MP lobby)
	strings["csr_ready"] = "READY"
	strings["csr_ready_confirmed"] = "READY \xe2\x9c\x93"
	strings["csr_ready_waiting"] = "Waiting"
	strings["csr_ready_starting"] = "Starting in"
	strings["csr_ready_launching"] = "Launching..."

	-- Override "Loud Modifiers" with "Items"
	strings["menu_cs_modifier_loud"] = "ITEMS"
	strings["menu_cs_modifiers_loud"] = "ITEMS"

	-- Override "Next Modifier" labels in Modifiers tab
	strings["menu_cs_next_modifier_in"] = "NEXT ITEM DROP IN"
	strings["menu_cs_next_modifier"] = "NEXT ITEM DROP"
	strings["menu_cs_next_modifier_forced"] = "NEXT MODIFIER: $next \xEE\x80\x98"
	strings["menu_cs_next_modifier_loud"] = "NEXT GUARANTEED ITEM: $next \xEE\x80\x98"
	strings["menu_cs_next_modifier_stealth"] = "NEXT MODIFIER: $next \xEE\x80\x98"

	-- Override "Starting Level" with "Starting Difficulty"
	strings["menu_cs_starting_level"] = "STARTING DIFFICULTY"
	-- Try different possible keys
	strings["menu_cs_starting_level_title"] = "STARTING DIFFICULTY"
	strings["menu_starting_level"] = "STARTING DIFFICULTY"

	-- === LOGBOOK LOCALIZATION ===
	strings["menu_csr_logbook"] = "LOGBOOK"
	strings["menu_csr_logbook_new"] = "LOGBOOK" .. utf8.char(0xE012) .. "  "
	strings["menu_csr_kill_bonus"] = "Kill Bonus"
	strings["menu_csr_cash_bonus"] = "Cash Bonus"
	strings["menu_csr_catchup_bonus"] = "Catchup Bonus"
	strings["menu_csr_rank_penalty"] = "Rank Penalty"

	-- Rarities
	strings["csr_logbook_rarity_common"] = "Common"
	strings["csr_logbook_rarity_uncommon"] = "Uncommon"
	strings["csr_logbook_rarity_rare"] = "Rare"
	strings["csr_logbook_rarity_contraband"] = "Contraband"

	local C = _G.CSR_ItemConstants or {}

	-- DOG TAGS
	local dt_hp = C.dog_tags_hp_bonus or 0.10
	strings["csr_logbook_dog_tags_name"] = "DOG TAGS"
	strings["csr_logbook_dog_tags_effect"] =
		string.format("Increases maximum health by {g}%g%%{/} (+%g%% per stack, linear).", dt_hp * 100, dt_hp * 100)
	strings["csr_logbook_dog_tags_notes"] = ""

	-- DUCT TAPE
	local tape_spd = C.duct_tape_speed_bonus or 0.05
	strings["csr_logbook_duct_tape_name"] = "DUCT TAPE"
	strings["csr_logbook_duct_tape_effect"] = string.format(
		"Increases interaction speed by {g}%g%%{/} (+%g%% per stack, linear).\nAffects lockpicking, bagging loot, repairing, etc. Does {r}not{/} apply to reviving teammates or uncuffing.",
		tape_spd * 100,
		tape_spd * 100
	)
	strings["csr_logbook_duct_tape_notes"] = ""

	-- ESCAPE PLAN
	local sn_cap = C.escape_plan_cap or 0.50
	local sn_k = (C.escape_plan_k_num or 3) / (C.escape_plan_k_den or 47)
	local sn_first = math.floor(sn_cap * sn_k / (1 + sn_k) * 100 + 0.5)
	strings["csr_logbook_escape_plan_name"] = "ESCAPE PLAN"
	strings["csr_logbook_escape_plan_effect"] =
		string.format("Increases movement speed by {g}%d%%{/} (+%d%% per stack, hyperbolic).", sn_first, sn_first)
	strings["csr_logbook_escape_plan_notes"] = ""

	-- WORN BAND-AID
	local ba_regen = C.worn_bandaid_regen or 5
	local ba_int = C.worn_bandaid_interval or 10
	strings["csr_logbook_worn_bandaid_name"] = "WORN BAND-AID"
	strings["csr_logbook_worn_bandaid_effect"] = string.format(
		"Increases health regeneration by {g}%g{/} (+%g per stack, linear) every %g seconds.",
		ba_regen,
		ba_regen,
		ba_int
	)
	strings["csr_logbook_worn_bandaid_notes"] = ""

	-- PIECE OF REBAR
	local rb_base = C.rebar_base_bonus or 0.15
	local rb_extra = C.rebar_extra_bonus or 0.10
	strings["csr_logbook_rebar_name"] = "PIECE OF REBAR"
	strings["csr_logbook_rebar_effect"] = string.format(
		"First hit on an enemy deals {g}+%g%%{/} (+%g%% per stack, linear) damage.",
		rb_base * 100,
		rb_extra * 100
	)
	strings["csr_logbook_rebar_notes"] = ""

	-- HALF-A-GLASS
	local hg_refill = C.half_a_glass_refill or 0.15
	local hg_first = C.half_a_glass_max_ammo_first or 0.02
	local hg_extra = C.half_a_glass_max_ammo_extra or 0.01
	strings["csr_logbook_half_a_glass_name"] = "HALF-A-GLASS"
	strings["csr_logbook_half_a_glass_effect"] = string.format(
		"Picking up a Gage package instantly refills {g}%g%%{/} ammo for primary and secondary weapons and increases their max ammo by {g}%g%%{/} (+%g%% per stack, linear) for the rest of the mission.",
		hg_refill * 100,
		hg_first * 100,
		hg_extra * 100
	)
	strings["csr_logbook_half_a_glass_notes"] = ""

	-- EVIDENCE ROUNDS
	local ap_dmg = C.ap_rounds_damage_bonus or 0.05
	strings["csr_logbook_evidence_rounds_name"] = "EVIDENCE ROUNDS"
	strings["csr_logbook_evidence_rounds_effect"] = string.format(
		"Increases damage from ALL sources by {g}%g%%{/} (+%g%% per stack, linear).",
		ap_dmg * 100,
		ap_dmg * 100
	)
	strings["csr_logbook_evidence_rounds_notes"] = ""

	-- FALCOGINI KEYS
	local keys_first = math.floor(100 / (1 + (C.car_keys_k_den or 19)) + 0.5)
	strings["csr_logbook_falcogini_keys_name"] = "FALCOGINI KEYS"
	strings["csr_logbook_falcogini_keys_effect"] = string.format(
		"Increases chance to dodge by {g}%d%%{/} (+%d%% per stack, hyperbolic).\nSuccessful dodging blocks incoming damage (does not work on self-inflicted damage).",
		keys_first,
		keys_first
	)
	strings["csr_logbook_falcogini_keys_notes"] = ""

	-- WOLF'S TOOLBOX
	local wt_norm_base = C.wolfs_toolbox_normal_base or 0.2
	local wt_norm_extra = C.wolfs_toolbox_normal_extra or 0.1
	local wt_spec_base = C.wolfs_toolbox_special_base or 1.0
	local wt_spec_extra = C.wolfs_toolbox_special_extra or 0.5
	strings["csr_logbook_wolfs_toolbox_name"] = "WOLF'S TOOLBOX"
	strings["csr_logbook_wolfs_toolbox_effect"] = string.format(
		"Killing regular enemies reduces active drill/saw timer by {g}%g second(s){/} (+%gs per stack, linear).\nKilling special enemies reduces timer by {g}%g second(s){/} (+%gs per stack, linear).",
		wt_norm_base,
		wt_norm_extra,
		wt_spec_base,
		wt_spec_extra
	)
	strings["csr_logbook_wolfs_toolbox_notes"] = ""

	-- PINK SLIP
	local ps_pct = (C.pink_slip_base_percent or 0.01) * 100
	local ps_base_flat = C.pink_slip_base_flat or 4
	local ps_heal_extra = C.pink_slip_extra_heal or 6
	strings["csr_logbook_pink_slip_name"] = "PINK SLIP"
	strings["csr_logbook_pink_slip_effect"] = string.format(
		"Killing any enemy restores {g}%g%%{/} of max health + {g}%g{/} (+%g per stack, linear) health.",
		ps_pct,
		ps_base_flat,
		ps_heal_extra
	)
	strings["csr_logbook_pink_slip_notes"] = ""

	-- THE EDGE
	local te_threshold = (C.the_edge_hp_threshold or 0.10) * 100
	local te_pct = (C.the_edge_heal_pct or 0.20) * 100
	local te_flat = C.the_edge_heal_flat or 20
	local te_extra = C.the_edge_heal_flat_extra or 40
	local te_invuln = C.the_edge_invuln or 0.5
	local te_cd = C.the_edge_cooldown or 60
	strings["csr_logbook_the_edge_name"] = "THE EDGE"
	strings["csr_logbook_the_edge_effect"] = string.format(
		"When health drops below {r}%.0f%%{/}, restores {g}%.0f%%{/} max health + {g}%g{/} (+%g per stack) and grants {g}%.1fs{/} invulnerability.\n%gs cooldown.",
		te_threshold,
		te_pct,
		te_flat,
		te_extra,
		te_invuln,
		te_cd
	)
	strings["csr_logbook_the_edge_notes"] = ""

	-- OVERKILL RUSH
	local ok_first = C.overkill_rush_first_bonus or 0.02
	local ok_extra = C.overkill_rush_extra_bonus or 0.01
	local ok_stacks = C.overkill_rush_max_stacks or 4
	local ok_dur = C.overkill_rush_duration or 4.0
	strings["csr_logbook_overkill_rush_name"] = "OVERKILL RUSH"
	strings["csr_logbook_overkill_rush_effect"] = string.format(
		"Killing any enemy grants you a rush stack. For each rush stack your fire rate and reload speed increase by {g}%g%%{/} (+%g%% per stack, linear).\nAll rush stacks expire %g seconds after the last kill.",
		ok_first * 100,
		ok_extra * 100,
		ok_dur
	)
	strings["csr_logbook_overkill_rush_notes"] = ""

	-- BONNIE'S LUCKY CHIP
	local bc_chance = C.bonnie_chip_chance or 0.05
	local bc_cd = C.bonnie_chip_cooldown or 1.5
	strings["csr_logbook_bonnie_chip_name"] = "BONNIE'S LUCKY CHIP"
	strings["csr_logbook_bonnie_chip_effect"] = string.format(
		"Gain {g}%g%%{/} (+%g%% per stack, hyperbolic) chance to instantly kill an enemy on hit.\nHas %g second cooldown.",
		bc_chance * 100,
		bc_chance * 100,
		bc_cd
	)
	strings["csr_logbook_bonnie_chip_notes"] = ""

	-- PLUSH SHARK
	local ps_heal_pct = C.plush_shark_heal_pct or 1.00
	local ps_inv_base = C.plush_shark_invuln_base or 10
	local ps_inv_extra = C.plush_shark_invuln_extra or 20
	strings["csr_logbook_plush_shark_name"] = "PLUSH SHARK"
	strings["csr_logbook_plush_shark_effect"] = string.format(
		"Protects from lethal damage once per life.\nOn activation restores {g}%g%%{/} maximum health and {g}armor{/}, then grants invulnerability that lasts {g}%g seconds{/} (+%gs per stack, linear).\nCan be activated again if you were freed from custody.",
		ps_heal_pct * 100,
		ps_inv_base,
		ps_inv_extra
	)
	strings["csr_logbook_plush_shark_notes"] =
		"BLÅHAJ from IKEA. This cute plushie friend will save you even in the most hopeless situation. Just don't ask how."

	-- JIRO'S LAST WISH
	local jiro_dmg_bonus = C.jiro_melee_bonus or 0.50
	strings["csr_logbook_jiro_last_wish_name"] = "JIRO'S LAST WISH"
	strings["csr_logbook_jiro_last_wish_effect"] = string.format(
		"Grants an ability to sprint while charging a melee attack. Increases melee damage by {g}%d%%{/} (+%d%% per stack, linear).",
		jiro_dmg_bonus * 100,
		jiro_dmg_bonus * 100
	)
	strings["csr_logbook_jiro_last_wish_notes"] = ""

	-- DEAREST POSSESSION
	local dp_cap = C.dearest_armor_cap or 0.5
	local dp_decay = C.dearest_decay_rate or 0.20
	strings["csr_logbook_dearest_possession_name"] = "DEAREST POSSESSION"
	strings["csr_logbook_dearest_possession_effect"] = string.format(
		"Healing received at full HP is converted into temporary shields. Shield cap: {g}%g%%{/} of maximum health (+%g%% per stack, linear). Shields decay at {r}%g%%{/} per second.",
		dp_cap * 100,
		dp_cap * 100,
		dp_decay * 100
	)
	strings["csr_logbook_dearest_possession_notes"] = ""

	-- VIKLUND'S VINYL
	local vv_dmg_pct = C.viklund_chain_dmg_pct or 0.25
	local vv_count = C.viklund_chain_count or 2
	local vv_radius = (C.viklund_radius_base or 500) / 100
	local vv_rad_step = (C.viklund_radius_step or 200) / 100
	strings["csr_logbook_viklund_vinyl_name"] = "VIKLUND'S VINYL"
	strings["csr_logbook_viklund_vinyl_effect"] = string.format(
		"Gain {g}80%%{/} chance on hit to chain {g}%d{/} nearest enemies within {g}%gm{/} (+%gm per stack, linear) range. Chained enemies receive {g}%g%%{/} of the initial damage.",
		vv_count,
		vv_radius,
		vv_rad_step,
		vv_dmg_pct * 100
	)
	strings["csr_logbook_viklund_vinyl_notes"] = ""

	-- DOZER GUIDE
	local dz_armor = C.dozer_armor_bonus or 0.50
	local dz_dmg = C.dozer_damage_bonus or 0.05
	local dz_spd = C.dozer_speed_penalty or 0.15
	local dz_dodge = C.dozer_dodge_penalty or 5
	local dz_min = C.dozer_speed_min or 0.40
	strings["csr_logbook_dozer_guide_name"] = "DOZER GUIDE"
	strings["csr_logbook_dozer_guide_effect"] = string.format(
		"Increases armor by {g}%g%%{/} (+%g%% per stack, linear) and damage by {g}%g%%{/} (+%g%% per stack, linear) from ranged and melee weapons.\nBut decreases movement speed by {r}%g%%{/} (+%g%% per stack, linear) (cannot be lower than %g%% of normal movement speed) and chance to dodge by {r}%d{/} (+%d per stack, linear).",
		dz_armor * 100,
		dz_armor * 100,
		dz_dmg * 100,
		dz_dmg * 100,
		dz_spd * 100,
		dz_spd * 100,
		dz_min * 100,
		dz_dodge,
		dz_dodge
	)
	strings["csr_logbook_dozer_guide_notes"] = ""

	-- GLASS PISTOL
	local gp_dmg = C.glass_pistol_dmg_per_stack or 1.75
	local gp_div = C.glass_pistol_div_per_stack or 2
	strings["csr_logbook_glass_pistol_name"] = "GLASS PISTOL"
	strings["csr_logbook_glass_pistol_effect"] = string.format(
		"Multiplies damage from ranged and melee weapons by {g}x%g{/} (x%g per stack, multiplicative).\nBut divides max health and armor by {r}%d{/} (+%d per stack, multiplicative).",
		gp_dmg,
		gp_dmg,
		gp_div,
		gp_div
	)
	strings["csr_logbook_glass_pistol_notes"] = ""

	-- EQUALIZER
	local eq_bonus = C.equalizer_bonus or 0.5
	local eq_penalty = C.equalizer_penalty or 0.5
	strings["csr_logbook_equalizer_name"] = "EQUALIZER"
	strings["csr_logbook_equalizer_effect"] = string.format(
		"Increases damage against special enemies by {g}%g%%{/} (+%g%% per stack, linear).\nBut reduces damage against regular enemies by {r}%g%%{/} (-%g%% per stack, linear).",
		eq_bonus * 100,
		eq_bonus * 100,
		eq_penalty * 100,
		eq_penalty * 100
	)
	strings["csr_logbook_equalizer_notes"] = ""

	-- CROOKED BADGE
	strings["csr_logbook_crooked_badge_name"] = "CROOKED BADGE"
	strings["csr_logbook_crooked_badge_effect"] = string.format(
		"After each assault, {g}30%%{/} (+20%%, hyperbolic) chance to restore 1 down. Chance above 100%% guarantees multiple downs.\nBut bleedout timer is reduced by {r}10{/} (+1s, hyperbolic) seconds."
	)
	strings["csr_logbook_crooked_badge_notes"] = ""

	-- DEAD MAN'S TRIGGER
	local dmt_dmg_display = (C.dmt_base_damage or 2400) / 5
	local dmt_extra_display = (C.dmt_damage_per_stack or 1200) / 5
	local dmt_radius_m = (C.dmt_base_radius or 300) / 100
	local dmt_radius_step_m = (C.dmt_radius_per_stack or 200) / 100
	strings["csr_logbook_dead_mans_trigger_name"] = "DEAD MAN'S TRIGGER"
	local dmt_ally = C.dmt_ally_mult or 0.20
	strings["csr_logbook_dead_mans_trigger_effect"] = string.format(
		"When going down you explode dealing {g}%g{/} (+%g per stack, linear) damage in a {g}%g{/} (+%g per stack, linear) meter radius. Damage scales with Crime Spree rank.\nBut allies within the radius take {r}%g%%{/} of the damage.",
		dmt_dmg_display,
		dmt_extra_display,
		dmt_radius_m,
		dmt_radius_step_m,
		dmt_ally * 100
	)
	strings["csr_logbook_dead_mans_trigger_notes"] = ""

	-- === BONUS ITEM DROP ===
	strings["csr_bonus_drop_title"] = "BONUS DROP!"
	strings["csr_bonus_drop_dismiss"] = "Click to continue"
	strings["csr_stats_drop_chance"] = "Bonus Drop Chance"

	loc:add_localized_strings(strings)
end)

-- Counts active modifier stacks matching the given id prefix.
-- For player items (player_*) uses the per-player store via CSR_CountStacks.
-- For CS modifiers (csr_*) still uses active_modifiers().
local function count_modifier_stacks(id_prefix)
	-- Player items: use the new per-player store
	if string.find(id_prefix, "player_", 1, true) == 1 then
		return CSR_CountStacks(id_prefix)
	end
	-- CS modifiers: fall back to active_modifiers
	if not managers.crime_spree or not managers.crime_spree:is_active() then
		return 0
	end
	local count = 0
	for _, mod_data in ipairs(managers.crime_spree:active_modifiers() or {}) do
		if mod_data.id and string.find(mod_data.id, id_prefix, 1, true) == 1 then
			count = count + 1
		end
	end
	return count
end

-- Call counter used to show Total only on the first modifier entry
local call_counter = {}
local last_call_time = {}

-- Hook text() to dynamically append Total and handle context-specific localization
local original_text = LocalizationManager.text
function LocalizationManager:text(string_id, macros)
	if not string_id or type(string_id) ~= "string" then
		return original_text(self, string_id, macros)
	end

	local current_time = os.clock()

	-- SPECIAL CASE: Less Concealment - bypass vanilla system entirely
	-- to avoid the $value substitution problem
	if string_id == "menu_cs_modifier_less_concealment" then
		-- Base text without Total
		local base_text = "Stand Out\nDetection risk is increased by 3 (Stealth Only)"

		-- Show Total ONLY in the view menu (CSR_FilterForUI = true), NOT in the selection popup
		if CSR_FilterForUI then
			local total_stacks = count_modifier_stacks("csr_less_concealment")

			if total_stacks >= 1 then
				-- Reset counter if more than 0.5s has passed (new menu open)
				if last_call_time[string_id] and (current_time - last_call_time[string_id]) > 0.5 then
					call_counter[string_id] = 0
				end
				last_call_time[string_id] = current_time

				-- Increment counter
				call_counter[string_id] = (call_counter[string_id] or 0) + 1

				-- Show Total only on the first (top) modifier entry
				if call_counter[string_id] == 1 then
					local total_concealment = total_stacks * 3
					base_text = base_text .. " (Total: +" .. total_concealment .. " detection risk)"
				end
			end
		end

		return base_text
	end

	-- SPECIAL CASE: Heavy Sniper - vanilla string has no name, force-inject it
	if string.find(string_id, "heavy_sniper", 1, true) then
		return "ZEAL Heavy SWAT Marksman\nFor every Heavy SWAT that spawns, there is a chance that it will be replaced by a ZEAL Heavy SWAT Marksman"
	end

	-- All other keys - standard processing
	local result = original_text(self, string_id, macros)

	-- Replace "STARTING LEVEL" with "STARTING DIFFICULTY" everywhere
	if result and type(result) == "string" then
		if string.find(result, "STARTING LEVEL") then
			local new_text = "STARTING DIFFICULTY"
			result = string.gsub(result, "STARTING LEVEL:?", new_text .. ":")
		end
	end

	-- Show Total ONLY in the view menu (CSR_FilterForUI = true), NOT in the selection popup
	if CSR_FilterForUI then
		-- DOG TAGS - show Total for health
		if string_id == "menu_cs_modifier_player_health" then
			local stacks = count_modifier_stacks("player_health_boost")
			if stacks > 1 then
				-- Reset counter if more than 0.5s has passed (new menu open)
				if last_call_time[string_id] and (current_time - last_call_time[string_id]) > 0.5 then
					call_counter[string_id] = 0
				end
				last_call_time[string_id] = current_time

				-- Increment counter
				call_counter[string_id] = (call_counter[string_id] or 0) + 1

				-- Show Total only on the first (top) modifier entry
				if call_counter[string_id] == 1 then
					local total_percent = stacks * 10
					result = result .. " (Total: +" .. total_percent .. "% health)"
				end
			end
		end

		-- EVIDENCE ROUNDS - show Total for damage
		if string_id == "menu_cs_modifier_player_damage" then
			local stacks = count_modifier_stacks("player_damage_boost")
			if stacks > 1 then
				-- Reset counter if more than 0.5s has passed
				if last_call_time[string_id] and (current_time - last_call_time[string_id]) > 0.5 then
					call_counter[string_id] = 0
				end
				last_call_time[string_id] = current_time

				-- Increment counter
				call_counter[string_id] = (call_counter[string_id] or 0) + 1

				-- Show Total only on the first (top) modifier entry
				if call_counter[string_id] == 1 then
					local total_percent = stacks * 10
					result = result .. " (Total: +" .. total_percent .. "% damage)"
				end
			end
		end
	end

	-- BULLSEYE (Headshot Armor Regen) - append CSR scaling note in skill tree
	-- Vanilla key: "menu_prison_wife_beta_desc" (internal name for Bullseye skill)
	-- Contains both BASIC and ACE in one string, so we append once at the end.
	if string_id == "menu_prison_wife_beta_desc" then
		local armor_mult = CSR_ActiveBuffs and CSR_ActiveBuffs.passive_armor_multiplier
		if armor_mult and armor_mult > 1.0 then
			local bonus_pct = math.floor((armor_mult - 1) * 100 + 0.5)
			result = result
				.. "\n\nIn ##Crime Spree Roguelike##, armor regen is scaled by rank bonus (##+"
				.. bonus_pct
				.. "%##)."
		else
			result = result .. "\n\nIn ##Crime Spree Roguelike##, armor regen scales with rank."
		end
	end

	return result
end
