-- Crime Spree Roguelike - Mission completion bonuses
-- Cash-to-ranks conversion and MP difficulty catchup/penalty

if not RequiredScript then
	return
end

local function CSR_log(msg)
	if _G.CSR_Settings and _G.CSR_Settings.values and _G.CSR_Settings.values.debug_mode then
		log(msg)
	end
end

-- Helper: calculate current cumulative engine cash (bags + small loot) from the
-- vanilla loot manager.  Used both at mission start (snapshot) and end (delta).
local function CSR_CalcEngineCash()
	local bag_value = 0
	local secured = managers.loot and managers.loot._global and managers.loot._global.secured or {}
	for _, data in ipairs(secured) do
		if not tweak_data.carry.small_loot[data.carry_id] then
			bag_value = bag_value + managers.money:get_secured_bonus_bag_value(data.carry_id, data.multiplier)
		end
	end
	local small_loot_value = managers.loot:get_real_total_small_loot_value()
	return bag_value + small_loot_value
end

-- Snapshot engine cash at mission START so we can compute the delta at mission END.
-- This avoids the stale-global bug where CSR_ProcessedCash (set at previous heist's END)
-- is compared against values re-evaluated under a different game context.
Hooks:PostHook(CrimeSpreeManager, "on_mission_started", "CSR_SnapshotEngineCash", function(self)
	if not self:is_active() then
		return
	end
	self._csr_engine_cash_at_start = CSR_CalcEngineCash()
	CSR_log("[CSR Cash] Mission start snapshot: engine_cash=" .. tostring(self._csr_engine_cash_at_start))
end)

-- Override server_spree_level to return the HOST's rank when we have it.
-- CSR_MP_HostRank is set by _handle_handshake_ok (on join) and apply_rank_up (on level up),
-- and cleared by on_left_lobby. Checking the global directly instead of is_client()
-- avoids false negatives during mission loading when Network:session() may be nil.
local _original_server_spree_level = CrimeSpreeManager.server_spree_level
function CrimeSpreeManager:server_spree_level()
	if _G.CSR_MP_HostRank then
		return _G.CSR_MP_HostRank
	end
	return _original_server_spree_level(self)
end

-- PreHook: save current level and raw mission gain BEFORE vanilla runs
Hooks:PreHook(CrimeSpreeManager, "on_mission_completed", "CSR_SaveOldLevel", function(self, mission_id)
	if not self:is_active() then
		return
	end

	-- Store old levels so we can revert vanilla's changes and apply our own
	self._csr_old_level = self._global.spree_level or 0
	self._csr_old_reward_level = self._global.reward_level or 0

	-- Save raw mission gain before vanilla's catchup/penalty modifies it
	local mission_data = self:get_mission(mission_id)
	self._csr_raw_mission_add = mission_data and mission_data.add or 0
end)

-- PostHook: add bonus levels for bags and kills AFTER vanilla runs
Hooks:PostHook(CrimeSpreeManager, "on_mission_completed", "CSR_BagsKillsBonus", function(self, mission_id)
	if not self:is_active() or self:has_failed() then
		return
	end

	local is_client = _G.CSR_MP and CSR_MP.is_client and CSR_MP.is_client()

	-- Client in multiplayer: revert ALL vanilla changes and use raw mission gain.
	-- Vanilla applies its own catchup/penalty (subtracts level difference) which can reduce
	-- the gain to 0 when client is far ahead. We replace that with our own rank scaling formula.
	local base_gain = 0
	if is_client and self._csr_old_level then
		self._global.spree_level = self._csr_old_level
		self._global.reward_level = self._csr_old_reward_level or self._csr_old_level
		-- Use raw mission gain (before vanilla penalty), not the penalized result
		base_gain = self._csr_raw_mission_add or 0
		CSR_log("[CSR MP] Client: reverted vanilla changes, using raw mission_add=" .. base_gain)

		-- Note: do NOT read get_peer_spree_level(1) here — that returns vanilla rank only
		-- (without our bags/kills bonus) and would overwrite the correct CSR_MP_HostRank.
		-- broadcast_rank_up from the host sends the correct value.
	end

	CSR_log(
		"[CSR Mission] on_mission_completed PostHook: is_client="
			.. tostring(is_client)
			.. " base_gain="
			.. base_gain
			.. " CSR_MP_HostRank="
			.. tostring(_G.CSR_MP_HostRank)
	)

	local bonus = base_gain

	-- === CASH-TO-RANKS CONVERSION ===
	-- Total cash earned (bags + loose loot + kill cash) is converted to bonus ranks.
	-- Conversion rate = value of one money bag at current difficulty.
	-- Table lives in base_modifier.lua (_G.CSR_ItemConstants.cash_per_rank) so both
	-- the math here and the UI in cash_convert_animation.lua read the same source.
	local CASH_PER_RANK = (_G.CSR_ItemConstants and _G.CSR_ItemConstants.cash_per_rank)
		or {
			normal = 7500,
			hard = 37500,
			very_hard = 75000,
			overkill = 157500,
			mayhem = 270000,
			death_wish = 307500,
			death_sentence = 345000,
		}

	local current_diff = self._global.selected_difficulty or _G.CSR_CurrentDifficulty or "overkill"
	local cash_per_rank = CASH_PER_RANK[current_diff] or 157500

	-- Compute cash earned THIS mission only by subtracting the snapshot taken
	-- at mission start.  Both values use the same evaluation context (same job,
	-- same difficulty stars), so bag re-valuation drift is impossible.
	local engine_cash_now = CSR_CalcEngineCash()
	local engine_cash_start = self._csr_engine_cash_at_start or 0
	local new_cash = math.max(0, engine_cash_now - engine_cash_start)

	-- DIAGNOSTIC: always log cash values so we can see what the engine returns
	log(
		"[CSR DIAG] engine_cash_now="
			.. tostring(engine_cash_now)
			.. " engine_cash_start="
			.. tostring(engine_cash_start)
			.. " new_cash="
			.. tostring(new_cash)
			.. " cash_per_rank="
			.. tostring(cash_per_rank)
			.. " diff="
			.. tostring(current_diff)
			.. " bag_count="
			.. tostring(_G.CSR_MissionBagCount)
	)

	-- Add leftover cash carried over from previous conversion
	local carried_cash = _G.CSR_CarriedCash or 0
	local total_cash = new_cash + carried_cash

	local cash_bonus = math.floor(total_cash / cash_per_rank)
	local leftover_cash = total_cash - cash_bonus * cash_per_rank
	_G.CSR_CarriedCash = leftover_cash

	if cash_bonus > 0 then
		bonus = bonus + cash_bonus
		-- Gage Tokens: +1 per rank gained via cash-bonus (Shop currency).
		-- Base mission add (vanilla) does NOT grant tokens — only cash ranks do.
		if _G.CSR_AddTokens then
			CSR_AddTokens(cash_bonus)
		end
	end

	CSR_log(
		"[CSR Cash] total_cash="
			.. total_cash
			.. " carried_over="
			.. carried_cash
			.. " cash_per_rank="
			.. cash_per_rank
			.. " cash_bonus="
			.. cash_bonus
			.. " leftover="
			.. leftover_cash
			.. " total_bonus="
			.. bonus
	)

	-- === MULTIPLAYER DIFFICULTY SCALING ===
	-- Compare host vs client difficulty using reward multiplier ratio.
	-- Higher-difficulty host → catchup (ratio > 1, uncapped).
	-- Lower-difficulty host → penalty (ratio < 1, minimum 1 point).
	local DIFFICULTY_REWARD_MULT = {
		normal = 0.12,
		hard = 0.25,
		very_hard = 0.52,
		overkill = 1.0,
		mayhem = 1.28,
		death_wish = 1.41,
		death_sentence = 1.68,
	}

	local difficulty_multiplier = 1
	if bonus > 0 and is_client and _G.CSR_MP_HostDifficulty then
		local host_diff = _G.CSR_MP_HostDifficulty
		local client_diff = self._global.selected_difficulty or _G.CSR_CurrentDifficulty or "overkill"
		local host_mult = DIFFICULTY_REWARD_MULT[host_diff] or 1.0
		local client_mult = DIFFICULTY_REWARD_MULT[client_diff] or 1.0
		if client_mult > 0 then
			difficulty_multiplier = host_mult / client_mult
			local raw_bonus = bonus
			bonus = math.max(1, math.floor(bonus * difficulty_multiplier))
			CSR_log(
				"[CSR MP] Client difficulty scaling: host="
					.. host_diff
					.. "("
					.. host_mult
					.. ") client="
					.. client_diff
					.. "("
					.. client_mult
					.. ") mult="
					.. string.format("%.2f", difficulty_multiplier)
					.. " bonus "
					.. raw_bonus
					.. " -> "
					.. bonus
			)
		end
	end

	-- Vanilla already set _mission_completion_gain = mission_data.add (raw gain).
	-- We keep it as-is: bags, kills, and rank adjustment show as separate UI entries.

	-- === APPLY BONUS ===
	if bonus > 0 then
		self._global.spree_level = self._global.spree_level + bonus

		-- Update highest level for meta-progress
		self:_check_highest_level(self._global.spree_level)

		-- Update reward_level (drives experience/coins calculation)
		self._global.reward_level = self._global.reward_level + bonus

		-- Update rewards (experience, continental_coins, cash)
		self._global.unshown_rewards = self._global.unshown_rewards or {}
		for _, reward in ipairs(tweak_data.crime_spree.rewards) do
			self._global.unshown_rewards[reward.id] = (self._global.unshown_rewards[reward.id] or 0)
				+ bonus * reward.amount
		end
	end

	-- Host: always broadcast current rank to clients after mission completion.
	-- Must be OUTSIDE the bonus block — vanilla already increased spree_level by the
	-- base mission gain, and clients need to know the new total for item drop tracking.
	if not is_client and _G.CSR_MP and CSR_MP.broadcast_rank_up then
		CSR_MP.broadcast_rank_up(self._global.spree_level)
	end

	-- Store difficulty adjustment for UI (positive = catchup, negative = penalty)
	if difficulty_multiplier ~= 1 then
		self._csr_rank_adjustment = bonus - (base_gain + cash_bonus)
	else
		self._csr_rank_adjustment = 0
	end

	-- Store for UI display (bags_ui.lua reads cash_bonus, rank_ui.lua reads rank_adjustment)
	self._csr_bonus_bags = cash_bonus
	self._csr_total_cash = total_cash
end)

-- PostHook: update meta-progress stats
Hooks:PostHook(CrimeSpreeManager, "on_mission_completed", "CSR_UpdateMetaProgress", function(self)
	if not self:is_active() or self:has_failed() then
		return
	end

	if CSR_MetaProgress then
		CSR_MetaProgress:AddMission()
		CSR_MetaProgress:AddKills(self._csr_total_kills or 0)
		CSR_MetaProgress:AddBags(self._csr_bonus_bags or 0)

		-- Update highest level for the current difficulty
		local current_difficulty = self._global.selected_difficulty or CSR_CurrentDifficulty or "normal"
		CSR_MetaProgress:UpdateHighestLevelForDifficulty(current_difficulty, self:spree_level())

		-- Record cash and coins earned
		if self._global.unshown_rewards then
			if self._global.unshown_rewards.cash then
				CSR_MetaProgress:AddCash(self._global.unshown_rewards.cash)
			end
			if self._global.unshown_rewards.continental_coins then
				CSR_MetaProgress:AddCoins(self._global.unshown_rewards.continental_coins)
			end
		end

		CSR_MetaProgress:Save()
	end
end)
