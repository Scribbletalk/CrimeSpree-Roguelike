-- THE EDGE - Emergency heal on cooldown when critically low HP
-- Trigger: HP drops below threshold OR lethal damage while cooldown is ready
-- Effect: restore HP + invulnerability window
-- Architecture: PreHook on _check_bleed_out (catches lethal hits, like Plush Shark)
--              + PostHook on damage_* (catches non-lethal drops below threshold)

if not RequiredScript then
	return
end

local function CSR_log(msg)
	log("[CSR TheEdge] " .. tostring(msg))
end

ModifierTheEdge = ModifierTheEdge or class(CSRBaseModifier)
ModifierTheEdge.desc_id = "csr_the_edge_desc"

-- === ACTIVATION SOUND (XAudio, same pattern as Plush Shark) ===
CSR_log("theedge.lua loaded, ModPath=" .. tostring(ModPath))

local SAVED_MOD_PATH = ModPath
_G.CSR_TheEdgeSoundBuffer = _G.CSR_TheEdgeSoundBuffer or nil

if not _G.CSR_TheEdgeSoundBuffer then
	DelayedCalls:Add("CSR_LoadTheEdgeSound", 1.0, function()
		if _G.CSR_TheEdgeSoundBuffer then
			return
		end
		if not (_G.blt and _G.blt.xaudio) then
			CSR_log("XAudio not available")
			return
		end
		blt.xaudio.setup()

		local base_path = Application:base_path()
		if base_path and base_path:sub(-1) ~= "/" and base_path:sub(-1) ~= "\\" then
			base_path = base_path .. "/"
		end
		local relative_path = SAVED_MOD_PATH .. "assets/sounds/the_edge_activate.ogg"
		local absolute_path = base_path .. relative_path

		local path_to_load = relative_path
		local fh = io.open(absolute_path, "rb")
		if fh then
			fh:close()
			path_to_load = absolute_path
		else
			fh = io.open(relative_path, "rb")
			if fh then
				fh:close()
			else
				CSR_log("File NOT FOUND at either path: " .. absolute_path .. " | " .. relative_path)
				return
			end
		end

		local ok, buffer = pcall(function()
			return XAudio.Buffer:new(path_to_load)
		end)
		if ok and buffer then
			_G.CSR_TheEdgeSoundBuffer = buffer
			local len_ok, len = pcall(function()
				return buffer:get_length()
			end)
			CSR_log("Loaded " .. path_to_load .. " (length=" .. tostring(len_ok and len or "?") .. "s)")
		else
			CSR_log("Buffer FAILED for " .. path_to_load .. ": " .. tostring(buffer))
		end
	end)
end

-- Count stacks
local function get_edge_stacks()
	return CSR_CountStacks("player_the_edge_")
end

-- Only trigger for local player
local function is_local_player(self)
	local pu = managers.player and managers.player:player_unit()
	return pu and self._unit == pu
end

-- Check cooldown availability
local function is_cooldown_ready(self)
	local C = _G.CSR_ItemConstants or {}
	local cooldown = C.the_edge_cooldown or 60
	local now = TimerManager:game():time()
	if self._csr_edge_last_trigger and (now - self._csr_edge_last_trigger) < cooldown then
		return false
	end
	return true
end

-- Perform the heal and set invulnerability
local function do_edge_heal(self)
	local stacks = get_edge_stacks()
	if stacks <= 0 then
		return false
	end

	local C = _G.CSR_ItemConstants or {}
	local now = TimerManager:game():time()

	self._csr_edge_last_trigger = now

	-- Activation sound — 2D playback (relative to listener, no 3D attenuation).
	-- set_relative(true) makes position (0,0,0) track the listener, so the sound plays
	-- at full volume regardless of world location.
	if _G.CSR_TheEdgeSoundBuffer then
		if self._csr_edge_sound then
			pcall(function()
				if not self._csr_edge_sound:is_closed() then
					self._csr_edge_sound:stop()
					self._csr_edge_sound:close()
				end
			end)
		end
		local sv = _G.CSR_Settings and _G.CSR_Settings.values
		local vol = (sv and sv.the_edge_sound_volume ~= nil) and sv.the_edge_sound_volume or 0.5
		local ok, err = pcall(function()
			local src = XAudio.Source:new(_G.CSR_TheEdgeSoundBuffer)
			src:set_relative(true)
			src:set_volume(vol)
			src:play()
			self._csr_edge_sound = src
			CSR_log(
				"Source state after play: "
					.. tostring(src:get_state())
					.. " sfx_base_gain="
					.. tostring(XAudio._base_gains and XAudio._base_gains.sfx)
			)
		end)
		if not ok then
			CSR_log("Sound play FAILED: " .. tostring(err))
		else
			CSR_log("Sound play OK (vol=" .. tostring(vol) .. ")")
		end
	end

	-- VHUDPlus: show cooldown timer
	local cooldown = C.the_edge_cooldown or 60
	if CSR_VHUDPlusEvent then
		CSR_VHUDPlusEvent("timed_buff", "activate", "csr_the_edge_cd", {
			t = now,
			duration = cooldown,
		})
	end
	if CSR_WFHudEvent then
		CSR_WFHudEvent("activate", "the_edge_cd", { duration = cooldown })
	end
	if CSR_PocoHudEvent then
		CSR_PocoHudEvent("activate", "the_edge_cd", { duration = cooldown })
	end

	local max_hp = self:_max_health()
	if not max_hp or max_hp <= 0 then
		return false
	end

	local heal_pct = C.the_edge_heal_pct or 0.20
	local heal_flat_base = C.the_edge_heal_flat or 20
	local heal_flat_extra = C.the_edge_heal_flat_extra or 40

	-- Calculate heal amount (flat HP is display units -> convert to internal)
	local display_scale = tweak_data.gui and tweak_data.gui.stats_present_multiplier or 5
	local pct_heal = max_hp * heal_pct
	local flat_heal = (heal_flat_base + math.max(0, stacks - 1) * heal_flat_extra) / display_scale
	local total_heal = pct_heal + flat_heal

	local current_hp = self:get_real_health()
	local new_hp = math.min(math.max(current_hp, 0) + total_heal, max_hp)
	self:set_health(new_hp)

	-- Invulnerability window
	local invuln_time = C.the_edge_invuln or 0.5
	self._csr_edge_invuln_end = now + invuln_time
	self._csr_edge_saved_hp = new_hp

	-- VHUDPlus: show brief invulnerability timer
	if CSR_VHUDPlusEvent then
		CSR_VHUDPlusEvent("timed_buff", "activate", "csr_the_edge_invuln", {
			t = now,
			duration = invuln_time,
		})
	end
	if CSR_WFHudEvent then
		CSR_WFHudEvent("activate", "the_edge_invuln", { duration = invuln_time })
	end
	if CSR_PocoHudEvent then
		CSR_PocoHudEvent("activate", "the_edge_invuln", { duration = invuln_time })
	end

	CSR_log(
		"TRIGGERED! Stacks: "
			.. stacks
			.. " healed to: "
			.. string.format("%.1f", new_hp * display_scale)
			.. " display HP, next in "
			.. (C.the_edge_cooldown or 60)
			.. "s"
	)
	return true
end

-- === LETHAL DAMAGE: PreHook on _check_bleed_out (same pattern as Plush Shark) ===
-- Fires when HP hits 0, BEFORE vanilla processes bleed-out
Hooks:PreHook(PlayerDamage, "_check_bleed_out", "CSR_TheEdge_BleedOut", function(self)
	if not managers.crime_spree or not managers.crime_spree:is_active() then
		return
	end
	if not is_local_player(self) then
		return
	end
	if not self.get_real_health then
		return
	end
	if self:get_real_health() > 0 then
		return
	end
	if not is_cooldown_ready(self) then
		return
	end

	if do_edge_heal(self) then
		CSR_log("Prevented bleed-out via _check_bleed_out hook")
		return false
	end
end)

-- === NON-LETHAL DAMAGE: PostHook on damage functions ===
-- Catches cases where HP drops below threshold but stays above 0
local function check_edge_trigger(self)
	if not managers.crime_spree or not managers.crime_spree:is_active() then
		return
	end
	if not is_local_player(self) then
		return
	end
	if not self.get_real_health then
		return
	end

	local now = TimerManager:game():time()

	-- During invulnerability window: restore HP to saved amount
	if self._csr_edge_invuln_end and now < self._csr_edge_invuln_end then
		if self._csr_edge_saved_hp then
			self:set_health(self._csr_edge_saved_hp)
		end
		return
	end

	-- Skip if already dead/downed (handled by _check_bleed_out hook above)
	if self:get_real_health() <= 0 then
		return
	end

	if not is_cooldown_ready(self) then
		return
	end

	local stacks = get_edge_stacks()
	if stacks <= 0 then
		return
	end

	-- Check HP threshold
	local C = _G.CSR_ItemConstants or {}
	local current_hp = self:get_real_health()
	local max_hp = self:_max_health()
	if not max_hp or max_hp <= 0 then
		return
	end

	local threshold = C.the_edge_hp_threshold or 0.10
	if current_hp / max_hp >= threshold then
		return
	end

	do_edge_heal(self)
end

Hooks:PostHook(PlayerDamage, "damage_bullet", "CSR_TheEdge_Bullet", function(self)
	check_edge_trigger(self)
end)

Hooks:PostHook(PlayerDamage, "damage_melee", "CSR_TheEdge_Melee", function(self)
	check_edge_trigger(self)
end)

Hooks:PostHook(PlayerDamage, "damage_explosion", "CSR_TheEdge_Explosion", function(self)
	check_edge_trigger(self)
end)

-- Reset on mission start
Hooks:PostHook(PlayerDamage, "init", "CSR_TheEdge_Init", function(self)
	self._csr_edge_last_trigger = nil
	self._csr_edge_invuln_end = nil
	self._csr_edge_saved_hp = nil
end)
