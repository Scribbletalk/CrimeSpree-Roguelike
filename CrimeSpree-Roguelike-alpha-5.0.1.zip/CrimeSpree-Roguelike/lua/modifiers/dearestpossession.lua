-- DEAREST POSSESSION - Overheal to temporary armor
-- When healed at full HP, excess healing converts to temporary bonus armor.
-- Armor cap: 50% of base MaxArmor per stack.
-- Armor decays at 20% per second.

if not RequiredScript then
	return
end

ModifierDearestPossession = ModifierDearestPossession or class(CSRBaseModifier)
ModifierDearestPossession.desc_id = "csr_dearest_possession_desc"

local C = _G.CSR_ItemConstants or {}
local DECAY_RATE = C.dearest_decay_rate or 0.20

-- == DETECTION: Override set_health to intercept ALL heal sources ==
-- set_health receives the raw (uncapped) value, cap happens inside vanilla.
-- If the intended new HP exceeds base max HP → overheal → convert excess to armor.
local original_set_health = PlayerDamage.set_health

_G.CSR_SafeOverride(PlayerDamage, "set_health", "Dearest Possession", original_set_health, function(self, health)
	if self._csr_dp_in_set_health then
		return original_set_health(self, health)
	end

	if CSR_ActiveBuffs and CSR_ActiveBuffs.dearest_possession then
		local base_fn = _G.CSR_Original_MaxHealth
		local base_max_hp = base_fn and (base_fn(self) * (self._max_health_reduction or 1))

		if base_max_hp and health > base_max_hp then
			-- Only convert to DP armor when the player is already at full HP.
			-- Otherwise (modded perk decks that heal on damage), the "overheal"
			-- is really a catch-up heal following damage, and converting it to
			-- armor pegs HP at max → player appears immune to HP damage.
			local current_hp = self:get_real_health()
			if current_hp < base_max_hp - 0.01 then
				original_set_health(self, health)
				return
			end

			local stacks = CSR_ActiveBuffs.dearest_possession
			local base_armor = _G.CSR_Original_MaxArmor and _G.CSR_Original_MaxArmor(self) or self:_max_armor()
			local armor_cap = base_armor * (C.dearest_armor_cap or 0.5) * stacks

			local current_bonus = self._csr_dp_armor or 0
			local excess = health - base_max_hp
			local new_bonus = math.min(armor_cap, current_bonus + excess)

			if new_bonus > current_bonus then
				local dp_gain = new_bonus - current_bonus
				local current_actual = self:get_real_armor()

				self._csr_dp_armor = new_bonus
				local new_max = self:_max_armor()

				-- Pre-empt _check_update_max_armor so it doesn't proportionally re-scale
				-- both _armor and _current_armor_fill on the next update() tick.
				self._current_max_armor = new_max

				-- Add dp_gain on top of current armor directly (avoids set_armor which
				-- would trigger consume_armor_stored_health → change_health → recursion).
				local target = math.min(new_max, current_actual + dp_gain)
				self._armor = Application:digest_value(target, true)

				-- Seed the fill animation: _csr_dp_fill starts at the old armor value,
				-- below the new armor. Our update PostHook lerps it toward get_real_armor()
				-- and pushes it to the HUD each frame, producing the upward fill animation.
				-- (Warframe HUD replaces _update_armor_hud with a no-op and only updates
				-- the bar via a set_armor PostHook — which we can't call here without
				-- triggering consume_armor_stored_health → change_health → recursion.)
				self._csr_dp_fill = current_actual
			end

			self._csr_dp_in_set_health = true
			original_set_health(self, base_max_hp)
			self._csr_dp_in_set_health = false
			return
		end
	end

	original_set_health(self, health)
end)

-- == DECAY + HUD ANIMATION ==
-- PostHook on update handles both the armor decay math and the animated HUD push.
-- We own the bar display whenever dp_bonus > 0; Warframe HUD (or vanilla) takes over
-- the moment dp expires.
Hooks:PostHook(PlayerDamage, "update", "CSR_DearestPossession_Decay", function(self, unit, t, dt)
	if not CSR_ActiveBuffs or not CSR_ActiveBuffs.dearest_possession then
		return
	end
	local bonus = self._csr_dp_armor
	if not bonus or bonus <= 0 then
		return
	end

	-- Decay the dp bonus.
	local old_bonus = bonus
	local decayed = bonus * DECAY_RATE * dt
	self._csr_dp_armor = math.max(0, bonus - decayed)
	local dp_delta = old_bonus - self._csr_dp_armor

	-- Recompute max AFTER updating _csr_dp_armor so _max_armor() reflects the new value.
	local new_max = self:_max_armor()

	if dp_delta > 0 then
		-- max without the dp bonus = non-dp portion
		local non_dp_max = new_max - self._csr_dp_armor
		local current_armor = self:get_real_armor()

		-- Only reduce armor in the portion that exceeds non-dp max.
		-- This preserves base/item armor and only drains the dp bonus.
		local armor_above_base = math.max(0, current_armor - non_dp_max)
		local armor_reduction = math.min(armor_above_base, dp_delta)

		if armor_reduction > 0 then
			self._armor = Application:digest_value(current_armor - armor_reduction, true)
		end

		-- Sync _current_max_armor so _check_update_max_armor on the next
		-- update() tick sees no change and skips proportional rescaling.
		self._current_max_armor = new_max
	end

	-- HUD animation: drive the bar ourselves because Warframe HUD replaces
	-- _update_armor_hud with an empty function and only reacts to set_armor calls.
	-- We maintain _csr_dp_fill as our own lerp variable and push it to the HUD
	-- every frame while dp is active.
	if managers.hud then
		local real_armor = self:get_real_armor()

		-- Initialise fill to current armor on first activation (no jump).
		if not self._csr_dp_fill then
			self._csr_dp_fill = real_armor
		end

		-- Clamp fill to never exceed real armor: if armor dropped (damage), fill
		-- snaps down instantly rather than bouncing above the new armor value.
		self._csr_dp_fill = math.min(self._csr_dp_fill, real_armor)

		-- Lerp fill toward real armor.  When fill is below armor (gain case),
		-- this produces a smooth upward fill animation.  When armor is decaying
		-- gradually, fill tracks the change frame-by-frame (visually smooth).
		self._csr_dp_fill = math.lerp(self._csr_dp_fill, real_armor, 10 * dt)

		managers.hud:set_player_armor({ current = self._csr_dp_fill, total = new_max })

		-- Blue pulsing overlay on the armor ring (same visual as Maniac/Anarchist
		-- absorb and hostage absorption). Sum with real damage_absorption so other
		-- absorption sources stay visible while DP is active.
		local base_absorb = managers.player
				and managers.player.damage_absorption
				and managers.player:damage_absorption()
			or 0
		managers.hud:set_absorb_active(HUDManager.PLAYER_PANEL, base_absorb + self._csr_dp_armor)
	end

	-- When the bonus fully expires this frame, clear the fill tracker so the
	-- next activation starts fresh, then do one final HUD push with the correct
	-- (now base-only) max so the bar snaps to the right scale.
	if self._csr_dp_armor <= 0 then
		self._csr_dp_fill = nil
		if managers.hud and managers.hud.set_absorb_active then
			local base_absorb = managers.player
					and managers.player.damage_absorption
					and managers.player:damage_absorption()
				or 0
			managers.hud:set_absorb_active(HUDManager.PLAYER_PANEL, base_absorb)
		end
	end
end)

-- == INIT: Reset bonus on player spawn ==
Hooks:PostHook(PlayerDamage, "init", "CSR_DearestPossession_Init", function(self)
	self._csr_dp_armor = 0
	self._csr_dp_fill = nil
end)
